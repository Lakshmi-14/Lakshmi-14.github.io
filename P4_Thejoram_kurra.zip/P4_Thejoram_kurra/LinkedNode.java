/* NAME : Thejoram Kurra
 * COURSE NAME : Programming fundamentals
 * SEMESTER : Fall 2022
 * ASSIGNMENT NAME : Programming Assignment 4
 */

package P4_Thejoram_kurra;

import java.util.StringJoiner;

public class LinkedNode implements Collection {

	private Node head;

	private class Node {

		private int data;
		private Node next;

		public Node() {

		}

		public Node(int data) {
			this(data, null);
		}

		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}

		public int getData() {
			return data;
		}

		public void setData(int data) {
			this.data = data;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}

		@Override
		public String toString() {
			return "Node [data=" + data + ", next=" + next + "]";
		}

	}

	public LinkedNode() {
		head = null;
	}

	@Override
	public boolean add(int x) {
		if (!exists(x)) {
			Node newNode = new Node(x);
			if (head == null) {
				head = newNode;
			} else {
				newNode.setNext(head);
				head = newNode;
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean delete(int x) {
		if (exists(x)) {

			// System.err.println("Hi");
			Node tempNode = null;
			if (head.getData() == x) {

				head = (tempNode = head).getNext();
				tempNode.setNext(null);

			} else {
				tempNode = head.getNext();
				Node prevNode = head;

				while (tempNode.getData() != x) {
					prevNode = tempNode;
					tempNode = tempNode.getNext();
				}

				prevNode.setNext(tempNode.getNext());
			}

			tempNode.setNext(null);
			return true;
		}
		return false;
	}

	@Override
	public boolean exists(int x) {
		Node tempNode = head;
		while (tempNode != null) {
			if (tempNode.getData() == x)
				return true;

			tempNode = tempNode.getNext();
		}

		return false;
	}

	@Override
	public String toString() {
		StringJoiner sj = new StringJoiner(" ");
		Node tempNode = head;
		while (tempNode != null) {
			sj.add(String.valueOf(tempNode.getData()));
			tempNode = tempNode.getNext();
		}
		return sj.toString();
	}

}

interface Collection {
	public boolean add(int x);

	public boolean delete(int x);

	public boolean exists(int x);

	public String toString();
}
