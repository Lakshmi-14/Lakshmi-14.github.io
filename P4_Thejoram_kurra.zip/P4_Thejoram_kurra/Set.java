/* NAME : Thejoram Kurra
 * COURSE NAME : Programming fundamentals
 * SEMESTER : Fall 2022
 * ASSIGNMENT NAME : Programming Assignment 4
 */

package P4_Thejoram_kurra;

public class Set implements Collection {

	private LinkedNode ll;

	Set() {
		ll = new LinkedNode();
	}

	Set(LinkedNode ll) {
		this.ll = ll;
	}

	@Override
	public boolean add(int x) {
		boolean isSuccess = ll.add(x);
		System.out.println(ll.toString());
		return isSuccess;
	}

	@Override
	public boolean delete(int x) {
		boolean isSuccess = ll.delete(x);
		System.out.println(ll.toString());
		return isSuccess;
	}

	@Override
	public boolean exists(int x) {
		return ll.exists(x);
	}

	@Override
	public String toString() {
		return ll.toString();
	}

}
