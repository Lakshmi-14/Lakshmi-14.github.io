/* NAME : Thejoram Kurra
 * COURSE NAME : Programming fundamentals
 * SEMESTER : Fall 2022
 * ASSIGNMENT NAME : Programming Assignment 4
 */

package P4_Thejoram_kurra;

import java.util.Scanner;

public class Test {
	static Set set = new Set();

	public static void main(String[] args) {
		System.out.println("Programming Fundamentals");
		System.out.println("NAME : THEJORAM KURRA");
		System.out.println("PROGRAMMING ASSIGNMENT 4 - SET");
		try (Scanner sc = new Scanner(System.in)) {

			do {
				System.out.print("Enter Command: ");
				String input[] = sc.nextLine().split(" ");

				try {
					String operation = input[0].toLowerCase();
					int data = Integer.parseInt(input[1]);

					switch (operation) {
						case "add":
							set.add(data);
							break;
						case "del":
							set.delete(data);
							break;
						case "exists":
							System.out.println(set.exists(data));
							break;
						default:
							System.err.println("\nInvalid Input\n");
					}

				} catch (NumberFormatException | IndexOutOfBoundsException e) {
					System.err.println("wrong input entered. " + e.getMessage());
				} catch (Exception e) {
					e.printStackTrace();
				}

			} while (true);

		}
	}
}
